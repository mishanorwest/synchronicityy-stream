<?php

$seedprod_default_settings = '{  
   "api_key":"",
   "enable_coming_soon_mode":false,
   "enable_maintenance_mode":false,
   "enable_login_mode":false,
   "enable_404_mode":false
 }';

$seedprod_app_default_settings = '{  
   "facebook_g_app_id":"",
   "disable_seedprod_button":false
}';
