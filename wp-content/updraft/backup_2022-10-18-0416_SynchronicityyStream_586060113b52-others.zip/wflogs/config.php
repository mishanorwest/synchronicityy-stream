<?php exit('Access denied'); __halt_compiler(); ?>
******************************************************************
This file is used by the Wordfence Web Application Firewall. Read 
more at https://docs.wordfence.com/en/Web_Application_Firewall_FAQ
******************************************************************
a:6:{s:9:"wafStatus";s:7:"enabled";s:30:"learningModeGracePeriodEnabled";i:0;s:7:"authKey";s:64:"+O.TpLNfwX)![tTGiHQ=D(5Qk77Kb/lo7zl($o(WbRIU{>07c]#$[;VhSp&,I;3A";s:7:"version";s:5:"1.0.5";s:11:"wafDisabled";b:0;s:13:"attackDataKey";i:1629;}