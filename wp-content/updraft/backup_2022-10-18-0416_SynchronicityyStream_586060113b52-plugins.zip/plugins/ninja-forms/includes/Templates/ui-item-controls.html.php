<ul class="nf-item-controls">
    <li class="nf-item-delete"><a href="#"><span class="dashicons dashicons-dismiss"></span><span class="nf-tooltip"><?php esc_html_e( 'Delete', 'ninja-forms' ); ?></span></a></li>
    <li class="nf-item-duplicate"><a href="#"><span class="dashicons dashicons-admin-page"></span><span class="nf-tooltip"><?php esc_html_e( 'Duplicate', 'ninja-forms' ); ?></span></a></li>
    <li class="nf-item-edit"><a href="#"><span class="dashicons dashicons-admin-generic"></span><span class="nf-tooltip"><?php esc_html_e( 'Edit', 'ninja-forms' ); ?></span><span class="nf-item-editing"><?php esc_html_e( 'Editing field', 'ninja-forms' ); ?></span></a></li>
</ul>
